public class Hewan {
    String nama;
    String jenis;
    String suara;

    //Metode untuk menampilkan informasi hewan
    void tampilkanInfo(){
        System.out.println("Nama: " + nama);
        System.out.println("Jenis: " + jenis);
        System.out.println("Suara: " + suara);
        System.out.println();
    }
}